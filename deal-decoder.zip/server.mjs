import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';

const files = new Map([
  ['/', ['index.html', 'text/html']],
  ['/index.html', ['index.html', 'text/html']],
  ['/style.css', ['style.css', 'text/css']],
  ['/app.js', ['app.js', 'text/javascript']],
  ['/compare.mjs', ['compare.mjs', 'text/javascript']]
]);
const {SERPAPI_KEY, INVENTORY_FEED_URL, INVENTORY_FEED_TOKEN, PORT = '3000', HOST = '127.0.0.1'} = process.env;

async function json(url, headers = {}) {
  const response = await fetch(url, {headers, signal:AbortSignal.timeout(9000)});
  if (!response.ok) throw new Error('Provider request failed');
  return response.json();
}

async function online(product, location) {
  const params = new URLSearchParams({engine:'google_shopping', q:product, location,
    gl:'ca', hl:'en', api_key:SERPAPI_KEY});
  const data = await json('https://serpapi.com/search.json?' + params);
  if (data.error) throw new Error('Shopping response error');
  return (data.shopping_results ?? []).slice(0, 20).map((item) => ({
    title:item.title, store:item.source, url:item.link || item.product_link,
    price:item.extracted_price, type:'online', stock:'unknown',
    shipping:/^free (shipping|delivery)$/i.test(item.delivery || '') ? 0 : null
  }));
}

async function local(product, location) {
  const endpoint = new URL(INVENTORY_FEED_URL);
  endpoint.searchParams.set('product', product);
  endpoint.searchParams.set('location', location);
  const headers = INVENTORY_FEED_TOKEN ? {Authorization:`Bearer ${INVENTORY_FEED_TOKEN}`} : {};
  const data = await json(endpoint, headers);
  if (!Array.isArray(data.offers)) throw new Error('Invalid inventory response');
  return data.offers.slice(0, 40).filter((item) => item?.type === 'pickup' || item?.type === 'online');
}

function normalize(item, index) {
  if (!item || typeof item.store !== 'string' || !item.store.trim() ||
      !Number.isFinite(item.price) || item.price < 0 ||
      (item.currency !== undefined && item.currency !== 'CAD')) return null;
  const text = (value, max) => typeof value === 'string' ? value.slice(0, max) : '';
  const numeric = (value) => Number.isFinite(value) && value >= 0 ? value : null;
  return {
    id:`live-${index}`, live:true, type:item.type,
    store:text(item.store, 100), title:text(item.title, 140), price:item.price, url:text(item.url, 2000),
    stock:['in','out'].includes(item.stock) ? item.stock : 'unknown',
    address:text(item.address, 200), km:numeric(item.km), minutes:numeric(item.minutes),
    shipping:numeric(item.shipping), fees:numeric(item.fees) ?? 0, eta:text(item.eta, 80)
  };
}

createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    if (request.method !== 'GET') { response.writeHead(405).end(); return; }
    if (url.pathname === '/api/offers') {
      const product = url.searchParams.get('product')?.trim();
      const location = url.searchParams.get('location')?.trim();
      response.setHeader('Cache-Control', 'no-store');
      response.setHeader('Content-Type', 'application/json; charset=utf-8');
      if (!product || !location || product.length > 140 || location.length > 110) {
        response.writeHead(400).end(JSON.stringify({error:'Enter a valid product and location.'}));
        return;
      }
      const jobs = [];
      if (SERPAPI_KEY) jobs.push(online(product, location));
      if (INVENTORY_FEED_URL) jobs.push(local(product, location));
      const results = await Promise.allSettled(jobs);
      const successful = results.filter((result) => result.status === 'fulfilled');
      if (!successful.length) {
        response.writeHead(503).end(JSON.stringify({error:'Live providers unavailable.'}));
        return;
      }
      const offers = successful.flatMap((result) => result.value).map(normalize).filter(Boolean);
      response.end(JSON.stringify({offers, partial:successful.length < jobs.length}));
      return;
    }
    const file = files.get(url.pathname);
    if (!file) { response.writeHead(404).end('Page unavailable'); return; }
    let body = await readFile(new URL('./dist/' + file[0], import.meta.url), 'utf8');
    if (file[0] === 'index.html' && (SERPAPI_KEY || INVENTORY_FEED_URL)) {
      body = body.replace('<html lang="en">', '<html lang="en" data-live="true">');
    }
    response.writeHead(200, {'Content-Type':file[1] + '; charset=utf-8', 'X-Content-Type-Options':'nosniff'}).end(body);
  } catch {
    response.writeHead(500).end('Service unavailable');
  }
}).listen(Number(PORT), HOST, () => console.log(`Deal Decoder listening at http://${HOST}:${PORT}`));
