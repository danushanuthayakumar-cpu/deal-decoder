# Deal Decoder

Compare CAD offers for any product using its exact model, variant, size, or pack count. Enter a Canadian city or postal code to build nearby pickup, map, and online shopping searches. The static version uses the results you verify and add. Offers are saved in the browser by product and starting location.

## Run the app

Use Node 20 or later. From this directory run:

    node server.mjs

Open http://127.0.0.1:3000. Alternatively, publish the contents of dist/ to a static host. The fictional examples are labelled and never saved as real offers.

## Optional live search

Set SERPAPI_KEY on the server for live Google Shopping leads. Enter a city with its province for the most reliable geographic match. Shopping search may return different variants, incomplete shipping information, and links that do not verify stock. Use the retailer page to confirm. Credentials belong in the server environment.

Set INVENTORY_FEED_URL to the HTTPS endpoint of a store-specific or aggregated inventory provider you have access to. Set INVENTORY_FEED_TOKEN if it requires bearer authentication. The server sends the entered product and location to configured providers. The inventory connector expects an endpoint or adapter that accepts GET query parameters product and location and returns a response like:

    {
      "offers": [{
        "type": "pickup",
        "title": "Exact model and variant",
        "store": "Retailer name",
        "address": "Branch address",
        "price": 39.99,
        "currency": "CAD",
        "stock": "in",
        "km": 4.2,
        "minutes": 12,
        "fees": 0,
        "url": "https://example.com/listing"
      }]
    }

Use stock "in", "out", or "unknown". Pickup km and minutes are one-way route estimates from the submitted location. Online offers can include numeric shipping and a text eta instead. Missing shipping or distance prevents ranking by total. The live connector does not supply an inventory feed, routing provider, or retailer agreements. If a pickup feed has no route estimates, use Directions and open Use offer to enter them. Before hosting the companion server publicly, add authentication or rate limits to protect provider quotas.

## How rankings work

Pickup total equals price plus fixed fees plus two times the one-way route distance times the selected cost per kilometre. Online total equals price plus shipping and fees. Time-adjusted ranking adds the value of round-trip pickup time. The shortest-trip ranking applies to pickup offers. Unverified or unavailable stock and incomplete totals cannot win. Delivery time is shown separately, and the app does not estimate tax automatically.
